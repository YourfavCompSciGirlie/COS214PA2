#include "SoldierFactory.h"

SoldierFactory::SoldierFactory()
{
    cout << "Soldier Factory is in session..." << endl;
}

SoldierFactory::~SoldierFactory() {
    cout << "Womp womp.. Factory exploded :( " << endl;
}

