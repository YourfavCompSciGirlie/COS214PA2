#include "Memento.h"

Memento::Memento(int value1, int value2, int value3, int value4, string value5)
{
    this->healthPerSoldier = value1;
    this->damagePerSoldier = value2;
    this->defencePerSoldier = value3;
    this->amountOfSoldierPerUnit = value4;
    this->unitName = value5;
}
int Memento::getHealthPerSoldier() const
{
    return healthPerSoldier;
}
int Memento::getDamagePerSoldier() const
{
    return damagePerSoldier;
}
int Memento::getDefencePerSoldier() const
{
    return defencePerSoldier;
}
int Memento::getAmountOfSoldierPerUnit() const
{
    return amountOfSoldierPerUnit;
}
string Memento::getUnitName() const
{
    return unitName;
}